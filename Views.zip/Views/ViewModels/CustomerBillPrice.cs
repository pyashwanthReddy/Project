﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using HouseTax.Models;

namespace HouseTax.ViewModels
{
    public class CustomerBillPrice
    {
        [Key]
        public int customerId { get; set; }
        public int price { get; set; }
        public string customerName { get; set; }
        public string Area { get; set; }
        public string builtinArea { get; set; }
        public string houseType { get; set; }
        public int areainsqft { get; set; }
    }
}