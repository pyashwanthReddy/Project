﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HouseTax.Models;
using HouseTax.ViewModels;
using Rotativa;

namespace HouseTax.Controllers
{
    public class CustomerBillController : Controller
    {
        private masterEntities db = new masterEntities();

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginDetail adminDetail)
        {
            var isAdmin = db.LoginDetails.Where(a => a.username == adminDetail.username && a.password == adminDetail.password).SingleOrDefault();
            if (isAdmin != null)
            {
                return RedirectToAction("searchCustomer");
            }
            ModelState.AddModelError("password", "Usesrname/password incorrect");
            return View();
        }
        // GET: CustomerBill
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult customerRegister()
        {
            var res = db.CustomerDetails.Count();
            ViewBag.customerId = 1000 + res;
            return View();
        }

        [HttpPost]
        public ActionResult customerRegister(CustomerDetail customerDetail)
        {
            if (ModelState.IsValid)
            {
                db.CustomerDetails.Add(customerDetail);
                db.SaveChanges();
            }
            ModelState.Clear();
            var res = db.CustomerDetails.Count();
            ViewBag.customerId = 1000 + res;
            return View();
        }

        public ActionResult searchCustomerDetails()
        {
            var res = db.CustomerDetails.ToList();
            return View(res);
        }

        [HttpPost]
        public ActionResult searchCustomerDetails(int? customerId)
        {
            List<CustomerDetail> res = null;
            if (customerId != null)
            {
                res = db.CustomerDetails.Where(a => a.customerId == customerId).ToList();
                return View(res);
            }
            res = db.CustomerDetails.ToList();
            return View();
        }

        public ActionResult editCustomerDetails(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CustomerDetail customerDetail = db.CustomerDetails.Find(id);
            if (customerDetail == null)
            {
                return HttpNotFound();
            }
            return View(customerDetail);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult editCustomerDetails([Bind(Include = "customerId,customerName,mobileNumber,houseNo,houseType,builtInArea,areaInSqfts,area,Location,pincode")] CustomerDetail customerDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(customerDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("searchCustomerDetails");
            }
            return View(customerDetail);
        }

        public ActionResult generateBill(int? id)
        {
            CustomerDetail customer = db.CustomerDetails.Find(id);
            var bill = db.Bills.Where(a => a.customerId == id).ToList();
            bool toGenerate = false;
            if (bill != null)
            {
                foreach (var item in bill)
                {
                    if(item.billDate.Month == DateTime.Now.Month && item.billDate.Year == DateTime.Now.Year)
                    {
                        toGenerate = true;
                    }
                }
            }
            if (!toGenerate)
            {
                string area = customer.area;
                string houseType = customer.houseType;
                string builtInArea = customer.builtInArea;
                var price = db.Prices.Where(a => a.area == area && a.builtInArea == builtInArea && a.houseType == houseType).SingleOrDefault();
                CustomerBillPrice billPrice = new CustomerBillPrice()
                {
                    customerId = customer.customerId,
                    customerName = customer.customerName,
                    Area = customer.area,
                    builtinArea = customer.builtInArea,
                    areainsqft = customer.areaInSqfts,
                    houseType = customer.houseType,
                    price = price.pricepersqft * customer.areaInSqfts
                };
                return View(billPrice);
            }
            return Content("<html><head><script>alert('Bill Already generated for this Month'); window.location.href = '/CustomerBill/searchCustomerDetails'</script></head></html>");
        }

        public ActionResult saveBillDetails(CustomerBillPrice customerBillPrice)
        {
            Bill bill = new Bill();
            bill.billDate = DateTime.Now.Date;
            string dueDate = DateTime.Now.Month.ToString() + "/" + "25" + "/" + DateTime.Now.Year.ToString() + " 00:00:00 AM";
            bill.billDueDate = DateTime.Parse(dueDate).Date;
            bill.billAmount = customerBillPrice.price;
            bill.customerId = customerBillPrice.customerId;
            bill.status = "Pending";
            bill.fine = 0;
            db.Bills.Add(bill);
            db.SaveChanges();
            return RedirectToAction("trackBills");
        }

        public ActionResult payBills()
        {
            var res = db.Bills.Where(a=>a.status == "Pending").ToList();
            return View(res);
        }

        [HttpPost]
        public ActionResult payBills(int? billId)
        {
            List<Bill> res = null;
            if (billId != null)
            {
                res = db.Bills.Where(a => a.billId == billId && a.status == "Pending").ToList();
                return View(res);
            }
            res = db.Bills.Where(a => a.status == "Pending").ToList();
            return View();
        }

        public ActionResult amountSummary(int? id)
        {
            var res = db.Bills.Where(a => a.billId == id).ToList();
            res[0].fine = 0;
            if(DateTime.Now.Date > res[0].billDueDate)
            {
                double overduedays = (DateTime.Now.Date - res[0].billDueDate).TotalDays;
                res[0].fine = Convert.ToInt32(overduedays) + 10;
            }
            return View(res);
        }

        public ActionResult updatePayStatus(int? id, int? fine)
        {
            var bill = db.Bills.Where(a => a.billId == id).SingleOrDefault();
            bill.status = "Paid";
            bill.fine = fine;
            db.Entry(bill).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("trackBills");
        }

        public ActionResult trackBills()
        {
            var res = db.Bills.ToList();
            return View(res);
        }

        public ActionResult PrintAllReport()
        {
            var report = new ActionAsPdf("reportforPaidCustomer");
            return report;
        }

        public ActionResult reportforPaidCustomer()
        {
            var res = db.Bills.Where(a=>a.status == "Paid").ToList();
            return View(res);
        }
    }
}